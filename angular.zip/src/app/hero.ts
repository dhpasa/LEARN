/**
 * Created by linliuan on 2017/3/13.
 */
export class Hero{
  id:number;
  name:string;
}
