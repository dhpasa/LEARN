import {Http} from "@angular/http";
import {Observable} from "rxjs/Observable";
import {Hero} from "./hero";
import {Injectable} from "@angular/core";
import 'rxjs/add/operator/map';
/**
 * Created by linliuan on 2017/3/22.
 */
@Injectable()
export class HeroSearchService{
  constructor(private http: Http){}

  search(term: string): Observable<Hero[]>{
    return this.http.get('app/heroes/?name=${term}`')
      .map(response => response.json().data as Hero[]);
  }
}
